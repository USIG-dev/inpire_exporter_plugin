def classFactory(iface):
    from .inspire_exporter import InspireExporter
    return InspireExporter(iface)
