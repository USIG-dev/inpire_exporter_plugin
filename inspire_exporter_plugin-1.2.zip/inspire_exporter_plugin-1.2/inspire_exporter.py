# -*- coding: utf-8 -*-
import os
import re
import unicodedata
import uuid
from datetime import date
import xml.etree.ElementTree as ET
from qgis.PyQt.QtWidgets import QAction, QFileDialog
from qgis.PyQt.QtXml import QDomDocument
from qgis.PyQt.QtWidgets import (
    QAction,
    QFileDialog,
    QDialog,
    QVBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
)

from qgis.core import (
    Qgis,
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsProject,
    QgsVectorLayer,
)



NS = {
    "gmd": "http://www.isotc211.org/2005/gmd",
    "gco": "http://www.isotc211.org/2005/gco",
    "gmx": "http://www.isotc211.org/2005/gmx",
    "xlink": "http://www.w3.org/1999/xlink",
}

for prefix, uri in NS.items():
    ET.register_namespace(prefix, uri)

ISO_CODELIST = "http://standards.iso.org/iso/19139/resources/gmxCodelists.xml#"
LANGUAGE_CODELIST = "http://www.loc.gov/standards/iso639-2/"
UOM_METRE = "http://standards.iso.org/ittf/PubliclyAvailableStandards/ISO_19139_Schemas/resources/uom/ML_gmxUom.xml#m"
INSPIRE_THEME_THESAURUS = "http://www.eionet.europa.eu/gemet/inspire_themes"
INSPIRE_THEME_CITATION = "http://inspire.ec.europa.eu/id/citation/voc/gemet-inspire-themes-1.0"

LANGUAGE_LABELS = {
    "por": "Português",
    "eng": "Inglês",
    "zxx": "Sem conteúdo linguístico",
}

CODE_LABELS = {
    "CI_DateTypeCode": {
        "creation": "Criação",
        "publication": "Publicação",
        "revision": "Revisão",
    },
    "CI_RoleCode": {
        "pointOfContact": "contacto",
        "distributor": "distribuidor",
        "originator": "produtor",
        "owner": "detentor",
        "custodian": "tutor",
    },
    "CI_OnLineFunctionCode": {
        "download": "Descarregamento",
        "information": "Informação",
        "search": "Pesquisa",
        "order": "Encomenda",
    },
    "MD_CharacterSetCode": {
        "utf8": "UTF-8",
    },
    "MD_MaintenanceFrequencyCode": {
        "continual": "Contínua",
        "daily": "Diária",
        "weekly": "Semanal",
        "fortnightly": "Quinzenal",
        "monthly": "Mensal",
        "quarterly": "Trimestral",
        "biannually": "Semestral",
        "annually": "Anual",
        "asNeeded": "Conforme necessário",
        "irregular": "Irregular",
        "notPlanned": "Não planeada",
        "unknown": "Desconhecida",
    },
    "MD_RestrictionCode": {
        "otherRestrictions": "Outras Restrições",
        "copyright": "Direitos de Autor",
        "license": "Sujeito a Licenciamento",
        "intellectualPropertyRights": "Direitos de Propriedade Intelectual",
        "restricted": "Restrito",
    },
    "MD_ScopeCode": {
        "dataset": "Conjunto de Dados Geográficos",
        "series": "Série",
        "service": "Serviço",
    },
    "MD_SpatialRepresentationTypeCode": {
        "vector": "Vectorial",
        "grid": "Matricial",
        "textTable": "Texto Tabela",
    },
}

INSPIRE_THEMES_PT = {
    "ac": "Condições atmosféricas",
    "ad": "Endereços",
    "af": "Instalações agrícolas e aquícolas",
    "am": "Zonas de gestão/restrição/regulamentação e unidades de referência",
    "au": "Unidades administrativas",
    "br": "Regiões biogeográficas",
    "bu": "Edifícios",
    "cp": "Parcelas cadastrais",
    "ef": "Instalações de monitorização do ambiente",
    "el": "Altitude",
    "er": "Recursos energéticos",
    "ge": "Geologia",
    "gg": "Sistemas de quadrículas geográficas",
    "gn": "Toponímia",
    "hb": "Habitats e biótopos",
    "hh": "Saúde humana e segurança",
    "hy": "Hidrografia",
    "lc": "Ocupação do solo",
    "lu": "Uso do solo",
    "mf": "Características geometeorológicas",
    "mr": "Recursos minerais",
    "nz": "Zonas de risco natural",
    "of": "Características oceanográficas",
    "oi": "Ortoimagens",
    "pd": "Distribuição da população — demografia",
    "pf": "Instalações industriais e de produção",
    "ps": "Sítios protegidos",
    "rs": "Sistemas de referência",
    "sd": "Distribuição das espécies",
    "so": "Solo",
    "sr": "Regiões marinhas",
    "su": "Unidades estatísticas",
    "tn": "Redes de transporte",
    "us": "Serviços de utilidade pública e do Estado",
}

INSPIRE_THEMES_EN = {
    "ac": "Atmospheric conditions",
    "ad": "Addresses",
    "af": "Agricultural and aquaculture facilities",
    "am": "Area management/restriction/regulation zones and reporting units",
    "au": "Administrative units",
    "br": "Bio-geographical regions",
    "bu": "Buildings",
    "cp": "Cadastral parcels",
    "ef": "Environmental monitoring facilities",
    "el": "Elevation",
    "er": "Energy resources",
    "ge": "Geology",
    "gg": "Geographical grid systems",
    "gn": "Geographical names",
    "hb": "Habitats and biotopes",
    "hh": "Human health and safety",
    "hy": "Hydrography",
    "lc": "Land cover",
    "lu": "Land use",
    "mf": "Meteorological geographical features",
    "mr": "Mineral resources",
    "nz": "Natural risk zones",
    "of": "Oceanographic geographical features",
    "oi": "Orthoimagery",
    "pd": "Population distribution - demography",
    "pf": "Production and industrial facilities",
    "ps": "Protected sites",
    "rs": "Coordinate reference systems",
    "sd": "Species distribution",
    "so": "Soil",
    "sr": "Sea regions",
    "su": "Statistical units",
    "tn": "Transport networks",
    "us": "Utility and governmental services",
}

THEME_TO_TOPIC_CATEGORY = {
    "ac": "climatologyMeteorologyAtmosphere",
    "ad": "location",
    "af": "farming",
    "am": "planningCadastre",
    "au": "boundaries",
    "br": "biota",
    "bu": "structure",
    "cp": "planningCadastre",
    "ef": "environment",
    "el": "elevation",
    "er": "economy",
    "ge": "geoscientificInformation",
    "gg": "location",
    "gn": "location",
    "hb": "biota",
    "hh": "health",
    "hy": "inlandWaters",
    "lc": "imageryBaseMapsEarthCover",
    "lu": "planningCadastre",
    "mf": "climatologyMeteorologyAtmosphere",
    "mr": "economy",
    "nz": "geoscientificInformation",
    "of": "oceans",
    "oi": "imageryBaseMapsEarthCover",
    "pd": "society",
    "pf": "structure",
    "ps": "environment",
    "rs": "location",
    "sd": "biota",
    "so": "geoscientificInformation",
    "sr": "oceans",
    "su": "boundaries",
    "tn": "transportation",
    "us": "utilitiesCommunication",
}

VALID_TOPIC_CATEGORIES = {
    "farming",
    "biota",
    "boundaries",
    "climatologyMeteorologyAtmosphere",
    "economy",
    "elevation",
    "environment",
    "geoscientificInformation",
    "health",
    "imageryBaseMapsEarthCover",
    "intelligenceMilitary",
    "inlandWaters",
    "location",
    "oceans",
    "planningCadastre",
    "society",
    "structure",
    "transportation",
    "utilitiesCommunication",
}

FORMAT_BY_EXTENSION = {
    ".csv": ("CSV", "não se aplica"),
    ".dgn": ("Microstation DGN", "desconhecida"),
    ".dwg": ("AutoCAD DWG", "desconhecida"),
    ".dxf": ("AutoCAD DXF", "desconhecida"),
    ".geojson": ("GeoJSON", "não se aplica"),
    ".gpkg": ("GeoPackage", "desconhecida"),
    ".gml": ("GML", "desconhecida"),
    ".kml": ("KML", "desconhecida"),
    ".shp": ("ESRI Shapefile", "não se aplica"),
    ".sqlite": ("SQLite", "desconhecida"),
}


def qn(prefix, tag):
    return f"{{{NS[prefix]}}}{tag}"


def clean_text(value, default=""):
    if value is None:
        return default
    text = str(value).strip()
    return text if text else default


def normalise(value):
    text = unicodedata.normalize("NFKD", clean_text(value).casefold())
    text = "".join(char for char in text if not unicodedata.combining(char))
    return re.sub(r"[^a-z0-9]+", " ", text).strip()


def safe_filename(value):
    name = re.sub(r"[^A-Za-z0-9._-]+", "_", clean_text(value, "layer"))
    return name.strip("._") or "layer"


def build_theme_aliases():
    aliases = {}
    for code, label in INSPIRE_THEMES_PT.items():
        aliases[normalise(code)] = code
        aliases[normalise(label)] = code
        aliases[normalise(f"http://inspire.ec.europa.eu/theme/{code}")] = code
    for code, label in INSPIRE_THEMES_EN.items():
        aliases[normalise(label)] = code
    aliases[normalise("Prédios")] = "cp"
    aliases[normalise("Predios")] = "cp"
    aliases[normalise("Rede de transporte")] = "tn"
    return aliases


THEME_ALIASES = build_theme_aliases()


class InspireExporter:

    def __init__(self, iface):
        self.iface = iface

    def initGui(self):
        self.action = QAction("Exportar QMD + INSPIRE/MIG", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        self.iface.addPluginToMenu("&INSPIRE Exporter", self.action)

    def unload(self):
        self.iface.removePluginMenu("&INSPIRE Exporter", self.action)
        

    def ask_spatial_resolution(self, layer):

        dialog = QDialog()
        dialog.setWindowTitle(
            f"Resolução espacial - {layer.name()}"
        )

        layout = QVBoxLayout()

        label = QLabel(
            "Preencha pelo menos um campo:"
        )

        scale_input = QLineEdit()
        scale_input.setPlaceholderText(
            "Scale denominator (ex: 1000)"
        )

        distance_input = QLineEdit()
        distance_input.setPlaceholderText(
            "Spatial resolution distance (ex: 0.5)"
        )

        save_btn = QPushButton("Guardar")

        layout.addWidget(label)
        layout.addWidget(scale_input)
        layout.addWidget(distance_input)
        layout.addWidget(save_btn)

        dialog.setLayout(layout)

        def save_values():

            scale = scale_input.text().strip()
            distance = distance_input.text().strip()

            if scale:
                layer.setCustomProperty(
                    "inspire/scale_denominator",
                    scale
                )

            if distance:
                layer.setCustomProperty(
                    "inspire/spatial_resolution_distance",
                    distance
                )

            dialog.accept()

        save_btn.clicked.connect(save_values)

        dialog.exec()


    def run(self):
        base_folder = QFileDialog.getExistingDirectory(
            None,
            "Escolher pasta de exportação INSPIRE/MIG"
        )

        if not base_folder:
            return

        qmd_folder = os.path.join(base_folder, "QMD")
        inspire_folder = os.path.join(base_folder, "INSPIRE_MIG_FROM_QMD")
        os.makedirs(qmd_folder, exist_ok=True)
        os.makedirs(inspire_folder, exist_ok=True)

        project = QgsProject.instance()
        today = date.today().isoformat()
        exported = 0
        warnings = []

        for layer in project.mapLayers().values():
            if not isinstance(layer, QgsVectorLayer):
                continue
            
            md = layer.metadata()
            name = safe_filename(layer.name())

            qmd_doc = QDomDocument("qgis")
            root = qmd_doc.createElement("qgis")
            qmd_doc.appendChild(root)
            md.writeMetadataXml(root, qmd_doc)

            with open(os.path.join(qmd_folder, f"{name}.qmd"), "w", encoding="utf-8") as f:
                f.write(qmd_doc.toString())

            xml, layer_warnings = self.build_mig_xml(layer, md, today, project)
            warnings.extend(f"{layer.name()}: {warning}" for warning in layer_warnings)

            with open(os.path.join(inspire_folder, f"{name}_INSPIRE_MIG.xml"), "w", encoding="utf-8") as f:
                f.write(xml)

            exported += 1                
                       
            
        if warnings:
            warning_path = os.path.join(base_folder, "INSPIRE_WARNINGS.txt")
            with open(warning_path, "w", encoding="utf-8") as f:
                f.write("\n".join(warnings))

        message = f"{exported} camada(s) exportada(s)"
        level = Qgis.Info
        if warnings:
            message += "; ver INSPIRE_WARNINGS.txt"
            level = Qgis.Warning
            
        
        self.iface.messageBar().pushMessage(
            "INSPIRE Exporter",
            message,
            level=level,
            duration=8,
        )

    def build_mig_xml(self, layer, md, today, project):
        warnings = []
        title = clean_text(self.metadata_value(md, "title"), layer.name())
        abstract = clean_text(
            self.metadata_value(md, "abstract"),
            f"Conjunto de dados geográficos correspondente à camada {layer.name()}."
        )
        contact, contact_warnings = self.contact(md, layer)
        theme_codes, theme_warnings = self.inspire_theme_codes(md, layer)
        topic_category = self.topic_category(layer, theme_codes)
        bbox, bbox_warnings = self.wgs84_bbox(layer, project)
        crs_identifier, crs_code_space = self.crs_identifier(layer)
        resource_identifier = self.resource_identifier(layer, theme_codes[0])
        metadata_identifier = self.metadata_identifier(layer, resource_identifier)
        resource_language = self.resource_language(layer)
        lineage, lineage_warnings = self.lineage(md, layer)
        scale_denominator, distance, resolution_warnings = self.spatial_resolution(layer, md)
        distribution_format, distribution_warnings = self.distribution_format(layer)
        links = self.resource_links(md, layer)

        warnings.extend(theme_warnings)
        warnings.extend(bbox_warnings)
        warnings.extend(lineage_warnings)
        warnings.extend(resolution_warnings)
        warnings.extend(distribution_warnings)
        warnings.extend(contact_warnings)
        if not crs_identifier:
            warnings.append("a camada não tem CRS válido para declarar no Perfil MIG")

        root = ET.Element(qn("gmd", "MD_Metadata"))
        self.text_property(root, "fileIdentifier", metadata_identifier)
        self.language_property(root, "language", "por")
        self.code_property(root, "characterSet", "MD_CharacterSetCode", "utf8")
        self.scope_property(root, "hierarchyLevel", "dataset")
        self.responsible_party(root, "contact", contact, "pointOfContact")
        self.date_property(root, "dateStamp", today)
        self.text_property(root, "metadataStandardName", 'ISO 19115/19139 "Perfil MIG 2.0"')
        self.text_property(root, "metadataStandardVersion", "Perfil MIG v.2 Metadados para Conjuntos de Dados Geográficos - versão 2.0")

        if crs_identifier:
            self.reference_system(root, crs_identifier, crs_code_space)

        identification_info = self.child(root, "gmd", "identificationInfo")
        identification = self.child(
            identification_info,
            "gmd",
            "MD_DataIdentification",
            attrs={"id": f"md-{metadata_identifier.replace('-', '')}"},
        )
        self.citation(identification, title, today, resource_identifier)
        self.text_property(identification, "abstract", abstract)
        self.responsible_party(identification, "pointOfContact", contact, "pointOfContact")
        self.inspire_keywords(identification, theme_codes)
        self.resource_constraints(identification, layer, md)
        self.spatial_resolution_element(identification, scale_denominator, distance)
        self.code_property(
            identification,
            "spatialRepresentationType",
            "MD_SpatialRepresentationTypeCode",
            "vector",
        )
        self.language_property(identification, "language", resource_language)
        self.code_property(identification, "characterSet", "MD_CharacterSetCode", "utf8")
        self.topic_category_property(identification, topic_category)
        self.extent(identification, bbox)

        self.distribution(root, distribution_format, links, contact)
        self.data_quality(root, lineage, layer, theme_codes[0], today)

        xml = ET.tostring(root, encoding="utf-8", xml_declaration=True
                          ).decode("utf-8")
        return xml, warnings

    def child(self, parent, prefix, tag, text=None, attrs=None):
        element = ET.SubElement(parent, qn(prefix, tag), attrs or {})
        if text is not None:
            element.text = clean_text(text)
        return element

    def text_property(self, parent, property_name, text, anchor_href=None):
        prop = self.child(parent, "gmd", property_name)
        if anchor_href:
            self.child(prop, "gmx", "Anchor", text, attrs={qn("xlink", "href"): anchor_href})
        else:
            self.child(prop, "gco", "CharacterString", text)
        return prop

    def date_property(self, parent, property_name, value):
        prop = self.child(parent, "gmd", property_name)
        self.child(prop, "gco", "Date", value)
        return prop

    def code_property(self, parent, property_name, code_list_name, value):
        prop = self.child(parent, "gmd", property_name)
        self.child(
            prop,
            "gmd",
            code_list_name,
            CODE_LABELS.get(code_list_name, {}).get(value, value),
            attrs={
                "codeList": f"{ISO_CODELIST}{code_list_name}",
                "codeListValue": value,
            },
        )
        return prop

    def language_property(self, parent, property_name, language_code):
        prop = self.child(parent, "gmd", property_name)
        self.child(
            prop,
            "gmd",
            "LanguageCode",
            LANGUAGE_LABELS.get(language_code, language_code),
            attrs={
                "codeList": LANGUAGE_CODELIST,
                "codeListValue": language_code,
            },
        )
        return prop

    def scope_property(self, parent, property_name, value):
        prop = self.child(parent, "gmd", property_name)
        self.child(
            prop,
            "gmd",
            "MD_ScopeCode",
            CODE_LABELS["MD_ScopeCode"].get(value, value),
            attrs={
                "codeList": f"{ISO_CODELIST}MD_ScopeCode",
                "codeListValue": value,
            },
        )
        return prop

    def citation(self, parent, title, citation_date, identifier):
        citation_prop = self.child(parent, "gmd", "citation")
        citation = self.child(citation_prop, "gmd", "CI_Citation")
        self.text_property(citation, "title", title)
        self.ci_date(citation, citation_date, "revision")
        identifier_prop = self.child(citation, "gmd", "identifier")
        md_identifier = self.child(identifier_prop, "gmd", "MD_Identifier")
        self.text_property(md_identifier, "code", identifier)

    def ci_date(self, parent, value, date_type):
        date_prop = self.child(parent, "gmd", "date")
        ci_date = self.child(date_prop, "gmd", "CI_Date")
        self.date_property(ci_date, "date", value)
        self.code_property(ci_date, "dateType", "CI_DateTypeCode", date_type)

    def responsible_party(self, parent, property_name, contact, role):
        party_prop = self.child(parent, "gmd", property_name)
        party = self.child(party_prop, "gmd", "CI_ResponsibleParty")
        if contact.get("individual"):
            self.text_property(party, "individualName", contact["individual"])
        if contact.get("organisation"):
            self.text_property(party, "organisationName", contact["organisation"])

        contact_info = self.child(party, "gmd", "contactInfo")
        ci_contact = self.child(contact_info, "gmd", "CI_Contact")
        address = self.child(ci_contact, "gmd", "address")
        ci_address = self.child(address, "gmd", "CI_Address")
        if contact.get("city"):
            self.text_property(ci_address, "city", contact["city"])
        if contact.get("postal_code"):
            self.text_property(ci_address, "postalCode", contact["postal_code"])
        if contact.get("country"):
            self.text_property(ci_address, "country", contact["country"])
        if contact.get("email"):
            self.text_property(ci_address, "electronicMailAddress", contact["email"])
        self.code_property(party, "role", "CI_RoleCode", role)

    def reference_system(self, parent, crs_identifier, code_space):
        ref_prop = self.child(parent, "gmd", "referenceSystemInfo")
        ref_system = self.child(ref_prop, "gmd", "MD_ReferenceSystem")
        ref_identifier = self.child(ref_system, "gmd", "referenceSystemIdentifier")
        rs_identifier = self.child(ref_identifier, "gmd", "RS_Identifier")
        self.text_property(rs_identifier, "code", crs_identifier)
        self.text_property(rs_identifier, "codeSpace", code_space or "EPSG")

    def inspire_keywords(self, parent, theme_codes):
        keywords_prop = self.child(parent, "gmd", "descriptiveKeywords")
        keywords = self.child(keywords_prop, "gmd", "MD_Keywords")
        for theme_code in theme_codes:
            keyword = self.child(keywords, "gmd", "keyword")
            self.child(
                keyword,
                "gmx",
                "Anchor",
                INSPIRE_THEMES_PT[theme_code],
                attrs={qn("xlink", "href"): f"http://inspire.ec.europa.eu/theme/{theme_code}"},
            )
        self.code_property(keywords, "type", "MD_KeywordTypeCode", "theme")

        thesaurus = self.child(
            keywords,
            "gmd",
            "thesaurusName",
            attrs={qn("xlink", "href"): INSPIRE_THEME_CITATION},
        )
        citation = self.child(thesaurus, "gmd", "CI_Citation")
        self.text_property(
            citation,
            "title",
            "GEMET - INSPIRE themes, version 1.0",
            anchor_href=INSPIRE_THEME_THESAURUS,
        )
        self.ci_date(citation, "2008-06-01", "creation")

    def resource_constraints(self, parent, layer, md):
        access_code = self.custom_property(layer, ["inspire/access_constraints", "metadata/access_constraints"])
        use_code = self.custom_property(layer, ["inspire/use_constraints", "metadata/use_constraints"])
        access_code = access_code if access_code in CODE_LABELS["MD_RestrictionCode"] else "otherRestrictions"
        use_code = use_code if use_code in CODE_LABELS["MD_RestrictionCode"] else "otherRestrictions"

        conditions = clean_text(
            self.custom_property(layer, ["inspire/conditions", "inspire/access_use_conditions"])
        )
        if not conditions:
            conditions = clean_text(self.metadata_value(md, "fees"))
        use_limitation = conditions or "Sem restrições"

        constraints_prop = self.child(parent, "gmd", "resourceConstraints")
        constraints = self.child(constraints_prop, "gmd", "MD_LegalConstraints")
        self.text_property(constraints, "useLimitation", use_limitation)
        self.code_property(constraints, "accessConstraints", "MD_RestrictionCode", access_code)
        self.code_property(constraints, "useConstraints", "MD_RestrictionCode", use_code)
        self.text_property(constraints, "otherConstraints", "Sem Restrições")

    def spatial_resolution_element(self, parent, scale_denominator, distance):
        prop = self.child(parent, "gmd", "spatialResolution")
        if not scale_denominator and not distance:
            prop.set(qn("gco", "nilReason"), "unknown")
            return

        resolution = self.child(prop, "gmd", "MD_Resolution")
        if scale_denominator:
            equivalent_scale = self.child(resolution, "gmd", "equivalentScale")
            fraction = self.child(equivalent_scale, "gmd", "MD_RepresentativeFraction")
            denominator = self.child(fraction, "gmd", "denominator")
            self.child(denominator, "gco", "Integer", str(int(scale_denominator)))
            return

        if distance:
            distance_prop = self.child(resolution, "gmd", "distance")
            self.child(distance_prop, "gco", "Distance", str(distance), attrs={"uom": UOM_METRE})
            return

    def topic_category_property(self, parent, value):
        prop = self.child(parent, "gmd", "topicCategory")
        self.child(prop, "gmd", "MD_TopicCategoryCode", value)

    def extent(self, parent, bbox):
        extent_prop = self.child(parent, "gmd", "extent")
        extent = self.child(extent_prop, "gmd", "EX_Extent")
        geographic_element = self.child(extent, "gmd", "geographicElement")
        box = self.child(geographic_element, "gmd", "EX_GeographicBoundingBox")
        extent_type_code = self.child(box, "gmd", "extentTypeCode")
        self.child(extent_type_code, "gco", "Boolean", "true")
        for tag, value in (
            ("westBoundLongitude", bbox[0]),
            ("eastBoundLongitude", bbox[2]),
            ("southBoundLatitude", bbox[1]),
            ("northBoundLatitude", bbox[3]),
        ):
            prop = self.child(box, "gmd", tag)
            self.child(prop, "gco", "Decimal", f"{value:.6f}")

    def distribution(self, parent, distribution_format, links, contact):
        distribution_info = self.child(parent, "gmd", "distributionInfo")
        distribution = self.child(distribution_info, "gmd", "MD_Distribution")

        format_prop = self.child(distribution, "gmd", "distributionFormat")
        md_format = self.child(format_prop, "gmd", "MD_Format")
        self.text_property(md_format, "name", distribution_format["name"])
        self.text_property(md_format, "version", distribution_format["version"])

        distributor_prop = self.child(distribution, "gmd", "distributor")
        distributor = self.child(distributor_prop, "gmd", "MD_Distributor")
        self.responsible_party(distributor, "distributorContact", contact, "distributor")

        if not links:
            return

        transfer_options = self.child(distribution, "gmd", "transferOptions")
        digital_transfer = self.child(transfer_options, "gmd", "MD_DigitalTransferOptions")
        for link in links:
            online_prop = self.child(digital_transfer, "gmd", "onLine")
            online = self.child(online_prop, "gmd", "CI_OnlineResource")
            linkage = self.child(online, "gmd", "linkage")
            self.child(linkage, "gmd", "URL", link["url"])
            if link.get("protocol"):
                self.text_property(online, "protocol", link["protocol"])
            if link.get("name"):
                self.text_property(online, "name", link["name"])
            if link.get("description"):
                self.text_property(online, "description", link["description"])
            self.code_property(online, "function", "CI_OnLineFunctionCode", link.get("function") or "download")

    def data_quality(self, parent, lineage, layer, theme_code, today):
        quality_info = self.child(parent, "gmd", "dataQualityInfo")
        quality = self.child(quality_info, "gmd", "DQ_DataQuality")
        scope = self.child(quality, "gmd", "scope")
        dq_scope = self.child(scope, "gmd", "DQ_Scope")
        self.scope_property(dq_scope, "level", "dataset")

        pass_value = self.conformity_pass(layer)
        if pass_value is not None:
            report = self.child(quality, "gmd", "report")
            consistency = self.child(report, "gmd", "DQ_DomainConsistency")
            result = self.child(consistency, "gmd", "result")
            conformance = self.child(result, "gmd", "DQ_ConformanceResult")
            specification = self.child(
                conformance,
                "gmd",
                "specification",
                attrs={qn("xlink", "href"): "http://inspire.ec.europa.eu/id/citation/ir/reg-1089-2010"},
            )
            citation = self.child(specification, "gmd", "CI_Citation")
            self.text_property(
                citation,
                "title",
                "Regulamento (UE) n.º 1089/2010 da Comissão, de 23 de novembro de 2010, relativo à interoperabilidade dos conjuntos e serviços de dados geográficos",
                anchor_href="http://data.europa.eu/eli/reg/2010/1089",
            )
            self.ci_date(citation, "2010-12-08", "publication")
            self.text_property(
                conformance,
                "explanation",
                f"Ver a especificação INSPIRE citada para o tema {INSPIRE_THEMES_PT[theme_code]}.",
            )
            pass_prop = self.child(conformance, "gmd", "pass")
            self.child(pass_prop, "gco", "Boolean", "true" if pass_value else "false")

        lineage_prop = self.child(quality, "gmd", "lineage")
        lineage_node = self.child(lineage_prop, "gmd", "LI_Lineage")
        self.text_property(lineage_node, "statement", lineage)

    def metadata_value(self, md, name):
        value = getattr(md, name, None)
        if callable(value):
            try:
                return value()
            except Exception:
                return None
        return value

    def custom_property(self, layer, keys):
        for key in keys:
            try:
                value = layer.customProperty(key)
            except Exception:
                value = None
            if clean_text(value):
                return clean_text(value)
        return ""

    def object_value(self, obj, names):
        if isinstance(obj, dict):
            for name in names:
                if clean_text(obj.get(name)):
                    return clean_text(obj.get(name))
            return ""
        for name in names:
            value = getattr(obj, name, None)
            if callable(value):
                try:
                    value = value()
                except Exception:
                    value = None
            if clean_text(value):
                return clean_text(value)
        return ""

    def contact(self, md, layer):
        organisation = self.custom_property(layer, ["inspire/organisation", "inspire/organization"])
        email = self.custom_property(layer, ["inspire/email", "metadata/email"])
        individual = self.custom_property(layer, ["inspire/contact_name", "metadata/contact_name"])
        city = self.custom_property(layer, ["inspire/city", "metadata/city"])
        postal_code = self.custom_property(layer, ["inspire/postal_code", "metadata/postal_code"])
        country = self.custom_property(layer, ["inspire/country", "metadata/country"])

        for contact in self.metadata_value(md, "contacts") or []:
            organisation = organisation or self.object_value(contact, ["organization", "organisation"])
            email = email or self.object_value(contact, ["email"])
            individual = individual or self.object_value(contact, ["name"])

        missing_fields = []
        if not clean_text(organisation):
            missing_fields.append("organização")
        if not clean_text(email):
            missing_fields.append("email")
        if not clean_text(city):
            missing_fields.append("localidade")
        if not clean_text(postal_code):
            missing_fields.append("código postal")
        if not clean_text(country):
            missing_fields.append("país")

        warnings = []
        if missing_fields:
            warnings.append(
                "dados de contacto em falta: "
                + ", ".join(missing_fields)
                + "; preencha as propriedades inspire/organisation, inspire/email, inspire/city, "
                "inspire/postal_code e inspire/country ou os contactos dos metadados QGIS"
            )

        return {
            "organisation": clean_text(organisation),
            "email": clean_text(email),
            "individual": clean_text(individual),
            "city": clean_text(city),
            "postal_code": clean_text(postal_code),
            "country": clean_text(country),
        }, warnings

    def metadata_keywords(self, md):
        def flatten(value):
            if isinstance(value, str):
                yield value
            elif isinstance(value, dict):
                for key, item in value.items():
                    yield key
                    yield from flatten(item)
            elif isinstance(value, (list, tuple, set)):
                for item in value:
                    yield from flatten(item)
            elif value is not None:
                yield str(value)

        return [clean_text(item) for item in flatten(self.metadata_value(md, "keywords")) if clean_text(item)]

    def inspire_theme_codes(self, md, layer):
        raw_theme = self.custom_property(
            layer,
            ["inspire/theme", "inspire/theme_code", "metadata/inspire_theme"],
        )
        candidates = []
        if raw_theme:
            candidates.extend(re.split(r"[,;|]", raw_theme))
        candidates.extend(self.metadata_keywords(md))
        candidates.append(layer.name())

        theme_codes = []
        for candidate in candidates:
            code = THEME_ALIASES.get(normalise(candidate))
            if code and code not in theme_codes:
                theme_codes.append(code)

        if theme_codes:
            return theme_codes, []

        return ["au"], [
            "tema INSPIRE não encontrado; usado por defeito 'Unidades administrativas'. "
            "Defina a propriedade da camada inspire/theme para ficar semanticamente conforme."
        ]

    def topic_category(self, layer, theme_codes):
        configured = self.custom_property(layer, ["inspire/topic_category", "metadata/topic_category"])
        if configured and configured in VALID_TOPIC_CATEGORIES:
            return configured
        return THEME_TO_TOPIC_CATEGORY.get(theme_codes[0], "boundaries")

    def metadata_identifier(self, layer, resource_identifier):
        configured = self.custom_property(layer, ["mig/file_identifier", "metadata/file_identifier"])
        if configured:
            try:
                return str(uuid.UUID(configured))
            except ValueError:
                pass
        return str(uuid.uuid5(uuid.NAMESPACE_URL, f"metadata:{resource_identifier}"))

    def resource_identifier(self, layer, theme_code):
        configured = self.custom_property(
            layer,
            ["inspire/identifier", "mig/resource_identifier", "metadata/identifier"],
        )
        if configured:
            return configured

        safe_layer = re.sub(r"[^A-Za-z0-9_.-]+", "_", layer.name()).strip("_")
        if safe_layer:
            return f"{theme_code.upper()}_{safe_layer}"
        return f"urn:uuid:{uuid.uuid5(uuid.NAMESPACE_URL, clean_text(layer.id(), layer.name()))}"

    def resource_language(self, layer):
        configured = self.custom_property(layer, ["inspire/resource_language", "metadata/resource_language"])
        configured = clean_text(configured).lower()
        if configured in LANGUAGE_LABELS:
            return configured
        return "por"

    def lineage(self, md, layer):
        configured = self.custom_property(layer, ["inspire/lineage", "mig/lineage", "metadata/lineage"])
        if configured:
            return configured, []

        history = self.metadata_value(md, "history")
        if isinstance(history, (list, tuple)):
            history = "; ".join(clean_text(item) for item in history if clean_text(item))
        if clean_text(history):
            return clean_text(history), []

        return "Histórico não documentado nos metadados da camada QGIS.", [
            "histórico/linhagem em falta; preencha a propriedade inspire/lineage"
        ]

    def spatial_resolution(self, layer, md):
        warnings = []
        denominator = self.custom_property(
            layer,
            ["mig/scale_denominator", "inspire/scale_denominator", "metadata/scale_denominator"],
        )
        distance = self.custom_property(
            layer,
            ["mig/spatial_resolution_distance", "inspire/spatial_resolution_distance", "metadata/spatial_resolution_distance"],
        )

        denominator = self.numeric_value(denominator)
        distance = self.numeric_value(distance)

        if not denominator and not distance:
            warnings.append(
                "resolução espacial em falta; preencha inspire/scale_denominator ou inspire/spatial_resolution_distance"
            )

        return denominator, distance, warnings

    def numeric_value(self, value):
        value = clean_text(value).replace(",", ".")
        if not value:
            return None
        try:
            number = float(value)
        except ValueError:
            return None
        if number <= 0:
            return None
        return number

    def conformity_pass(self, layer):
        configured = normalise(self.custom_property(layer, ["inspire/conformity_pass", "metadata/conformity_pass"]))
        if configured in {"true", "yes", "sim", "1", "conforme"}:
            return True
        if configured in {"false", "no", "nao", "0", "nao conforme"}:
            return False
        return None

    def crs_identifier(self, layer):
        try:
            crs = layer.crs()
            if crs and crs.isValid():
                authid = clean_text(crs.authid())
                if ":" in authid:
                    authority, code = authid.split(":", 1)
                    return code, authority
                return authid or clean_text(crs.description()), "EPSG"
        except Exception:
            pass
        return "", ""

    def wgs84_bbox(self, layer, project):
        warnings = []
        try:
            extent = layer.extent()
            source_crs = layer.crs()
            target_crs = QgsCoordinateReferenceSystem("EPSG:4326")
            if source_crs and source_crs.isValid() and source_crs.authid() != "EPSG:4326":
                transform = QgsCoordinateTransform(source_crs, target_crs, project)
                extent = transform.transformBoundingBox(extent)
        except Exception as exc:
            warnings.append(f"não foi possível transformar a extensão para EPSG:4326 ({exc})")
            extent = layer.extent()

        west, east = sorted((float(extent.xMinimum()), float(extent.xMaximum())))
        south, north = sorted((float(extent.yMinimum()), float(extent.yMaximum())))
        if not (-180 <= west <= 180 and -180 <= east <= 180 and -90 <= south <= 90 and -90 <= north <= 90):
            warnings.append("extensão geográfica fora dos limites WGS84; valores foram limitados ao intervalo válido")
        west = max(-180.0, min(180.0, west))
        east = max(-180.0, min(180.0, east))
        south = max(-90.0, min(90.0, south))
        north = max(-90.0, min(90.0, north))
        return (west, south, east, north), warnings

    def distribution_format(self, layer):
        configured = self.custom_property(layer, ["mig/distribution_format", "inspire/distribution_format"])
        version = self.custom_property(layer, ["mig/distribution_format_version", "inspire/distribution_format_version"])
        if configured:
            return {"name": configured, "version": version or "desconhecida"}, []

        source = ""
        try:
            source = clean_text(layer.source())
        except Exception:
            source = ""
        ext = os.path.splitext(source.split("|", 1)[0])[1].lower()
        if ext in FORMAT_BY_EXTENSION:
            name, guessed_version = FORMAT_BY_EXTENSION[ext]
            return {"name": name, "version": version or guessed_version}, []

        provider_name = ""
        try:
            provider_name = clean_text(layer.dataProvider().name())
        except Exception:
            provider_name = ""
        if provider_name:
            return {"name": provider_name, "version": version or "desconhecida"}, []

        return {"name": "Formato não documentado", "version": "desconhecida"}, [
            "formato de distribuição em falta; preencha mig/distribution_format"
        ]

    def resource_links(self, md, layer):
        links = []
        configured_url = self.custom_property(layer, ["mig/resource_locator", "inspire/resource_locator"])
        if configured_url:
            links.append({
                "url": configured_url,
                "protocol": self.custom_property(layer, ["mig/resource_locator_protocol", "inspire/resource_locator_protocol"]),
                "name": self.custom_property(layer, ["mig/resource_locator_name", "inspire/resource_locator_name"]),
                "description": self.custom_property(layer, ["mig/resource_locator_description", "inspire/resource_locator_description"]),
                "function": self.custom_property(layer, ["mig/resource_locator_function", "inspire/resource_locator_function"]) or "download",
            })

        for link in self.metadata_value(md, "links") or []:
            url = self.object_value(link, ["url", "link", "href"])
            if not url.lower().startswith(("http://", "https://")):
                continue
            links.append({
                "url": url,
                "protocol": self.object_value(link, ["protocol", "type"]),
                "name": self.object_value(link, ["name"]),
                "description": self.object_value(link, ["description"]),
                "function": self.object_value(link, ["function"]) or "download",
            })
        return links
